// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB9RqgRThTyGj2h_xPuGPG5ZHUCozVc08A",
  authDomain: "login-auth-bfd3f.firebaseapp.com",
  projectId: "login-auth-bfd3f",
  storageBucket: "login-auth-bfd3f.firebasestorage.app",
  messagingSenderId: "835836293122",
  appId: "1:835836293122:web:330bf8e6083d22e342371b"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);